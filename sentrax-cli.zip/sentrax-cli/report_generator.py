"""
report_generator.py - Renders scan results to terminal, JSON, and/or HTML
"""

import os
import json
import datetime
from colorama import Fore, Style

STATUS_COLORS = {
    "ok": Fore.GREEN,
    "warning": Fore.YELLOW,
    "error": Fore.RED,
}
STATUS_LABELS = {
    "ok": "OK",
    "warning": "WARNING",
    "error": "ERROR",
}


def print_terminal_report(domain, results):
    print(Style.BRIGHT + f"\n{'=' * 60}")
    print(f" SCAN REPORT — {domain}")
    print(f" Generated: {datetime.datetime.utcnow().isoformat()}Z")
    print(f"{'=' * 60}\n" + Style.RESET_ALL)

    total_findings = 0

    for module_name, res in results.items():
        color = STATUS_COLORS.get(res["status"], Fore.WHITE)
        label = STATUS_LABELS.get(res["status"], res["status"].upper())
        print(color + Style.BRIGHT + f"[{label}] {module_name.upper()}" + Style.RESET_ALL)

        if res.get("error") and res["status"] == "error":
            print(Fore.RED + f"   ! {res['error']}" + Style.RESET_ALL)

        findings = res.get("data", {}).get("findings") if isinstance(res.get("data"), dict) else None
        if findings:
            total_findings += len(findings)
            for f in findings:
                print(Fore.YELLOW + f"   - {f}" + Style.RESET_ALL)

        _print_module_summary(module_name, res)
        print()

    print(Style.BRIGHT + f"{'=' * 60}")
    print(f" TOTAL FINDINGS: {total_findings}")
    print(f"{'=' * 60}\n" + Style.RESET_ALL)


def _print_module_summary(name, res):
    data = res.get("data", {})
    if not isinstance(data, dict):
        return
    if name == "dns":
        for rtype, vals in data.items():
            if vals:
                print(Fore.CYAN + f"   {rtype}: " + Style.RESET_ALL + ", ".join(vals[:5]))
    elif name == "ssl":
        if data.get("issuer"):
            print(f"   Issuer: {data['issuer'].get('organizationName', data['issuer'].get('commonName', 'n/a'))}")
        if data.get("days_until_expiry") is not None:
            print(f"   Expires in: {data['days_until_expiry']} days")
        if data.get("protocol"):
            print(f"   Protocol: {data['protocol']}")
    elif name == "headers":
        if data.get("present_security_headers"):
            print(f"   Present headers: {len(data['present_security_headers'])} / configured checks")
    elif name == "subdomains":
        subs = data.get("subdomains", [])
        if subs:
            print(f"   Found {data.get('count_found', len(subs))} unique subdomains (showing up to {len(subs)}):")
            for s in subs[:10]:
                print(Fore.CYAN + f"     - {s}" + Style.RESET_ALL)
    elif name == "ports":
        open_ports = data.get("open_ports", [])
        if open_ports:
            print(f"   Open ports: " + ", ".join(f"{p['port']}/{p['service']}" for p in open_ports))
        else:
            print("   No open ports found among scanned list.")
    elif name == "tech_detect":
        tech = data.get("detected_technologies", [])
        if tech:
            print(f"   Detected: {', '.join(tech)}")
    elif name == "whois":
        if data.get("registrar"):
            print(f"   Registrar: {data['registrar']}")
        if data.get("expiration_date"):
            print(f"   Domain expires: {data['expiration_date']}")
    elif name == "robots_sitemap":
        if data.get("robots_txt_found"):
            print(f"   robots.txt found — {len(data.get('disallowed_paths', []))} disallowed paths")
        if data.get("sitemap_found"):
            print("   sitemap.xml found")


def save_json_report(domain, results, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    filename = os.path.join(output_dir, f"sentrax_{domain}_{timestamp}.json")
    payload = {
        "target": domain,
        "generated_at": datetime.datetime.utcnow().isoformat() + "Z",
        "results": results,
    }
    with open(filename, "w") as f:
        json.dump(payload, f, indent=2, default=str)
    return filename


def save_html_report(domain, results, output_dir):
    os.makedirs(output_dir, exist_ok=True)
    timestamp = datetime.datetime.utcnow().strftime("%Y%m%d_%H%M%S")
    filename = os.path.join(output_dir, f"sentrax_{domain}_{timestamp}.html")

    status_color = {"ok": "#39ff14", "warning": "#ffcc00", "error": "#ff4444"}
    sections = ""
    total_findings = 0

    for module_name, res in results.items():
        color = status_color.get(res["status"], "#ffffff")
        findings = res.get("data", {}).get("findings") if isinstance(res.get("data"), dict) else None
        findings_html = ""
        if findings:
            total_findings += len(findings)
            findings_html = "<ul>" + "".join(f"<li>{f}</li>" for f in findings) + "</ul>"
        error_html = f"<p class='error'>{res['error']}</p>" if res.get("error") and res["status"] == "error" else ""
        raw_json = json.dumps(res.get("data", {}), indent=2, default=str)
        sections += f"""
        <div class="module-card">
          <h3 style="color:{color}">{module_name.upper()} — {res['status'].upper()}</h3>
          {error_html}
          {findings_html}
          <details><summary>Raw data</summary><pre>{raw_json}</pre></details>
        </div>
        """

    html = f"""<!DOCTYPE html>
<html lang="en">
<head>
<meta charset="UTF-8">
<title>SentraX Report — {domain}</title>
<style>
  body {{ background:#0a0e14; color:#e0e0e0; font-family: 'Courier New', monospace; padding:2rem; }}
  h1 {{ color:#39ff14; }}
  .meta {{ color:#888; margin-bottom:2rem; }}
  .module-card {{ background:#111722; border:1px solid #1f2937; border-radius:8px; padding:1rem 1.5rem; margin-bottom:1rem; }}
  .error {{ color:#ff4444; }}
  ul {{ color:#ffcc00; }}
  pre {{ background:#0d1117; padding:1rem; overflow-x:auto; font-size:0.85rem; border-radius:6px; }}
  summary {{ cursor:pointer; color:#39ff14; margin-top:0.5rem; }}
  .totals {{ font-size:1.2rem; margin-top:2rem; color:#39ff14; }}
</style>
</head>
<body>
  <h1>SentraX-CLI Security Report</h1>
  <div class="meta">Target: {domain} &nbsp;|&nbsp; Generated: {datetime.datetime.utcnow().isoformat()}Z</div>
  {sections}
  <div class="totals">Total findings: {total_findings}</div>
</body>
</html>"""

    with open(filename, "w") as f:
        f.write(html)
    return filename
