#!/usr/bin/env python3
"""
SentraX-CLI - Terminal Website Security Scanner
Author: Arqam (CoreSec Solutions)

A modular, configurable CLI scanner: WHOIS, DNS, SSL/TLS, HTTP security
headers, passive subdomain discovery, common port checks, tech fingerprinting,
and robots.txt/sitemap discovery — with terminal, JSON, and HTML reporting.

Usage:
    python3 sentrax.py -d example.com
    python3 sentrax.py -d example.com --modules ssl,headers,dns
    python3 sentrax.py -d example.com --format json,html --output ./out
    python3 sentrax.py -d example.com --config myconfig.yaml
"""

import argparse
import sys
import os
import time
import yaml
from urllib.parse import urlparse

from colorama import init as colorama_init

from modules import banner
from modules import whois_check
from modules import dns_check
from modules import ssl_check
from modules import headers_check
from modules import subdomain_check
from modules import port_scan
from modules import tech_detect
from modules import robots_sitemap
import report_generator

MODULE_MAP = {
    "whois": whois_check,
    "dns": dns_check,
    "ssl": ssl_check,
    "headers": headers_check,
    "subdomains": subdomain_check,
    "ports": port_scan,
    "tech_detect": tech_detect,
    "robots_sitemap": robots_sitemap,
}

DEFAULT_CONFIG_PATH = os.path.join(os.path.dirname(os.path.abspath(__file__)), "config.yaml")


def load_config(path):
    if not os.path.exists(path):
        print(f"[!] Config file not found at {path}, using built-in defaults.")
        return {
            "general": {"timeout": 6, "threads": 20, "user_agent": "SentraX-CLI/1.0", "verbose": False},
            "modules": {m: True for m in MODULE_MAP},
            "ports": {"common_ports": [21, 22, 25, 53, 80, 110, 143, 443, 465, 587, 993, 995, 3306, 3389, 5432, 8080, 8443]},
            "subdomains": {"source": "crtsh", "max_results": 50},
            "report": {"formats": ["terminal", "json"], "output_dir": "reports", "include_raw_data": True},
        }
    with open(path, "r") as f:
        return yaml.safe_load(f)


def normalize_domain(raw):
    raw = raw.strip()
    if "://" in raw:
        parsed = urlparse(raw)
        return parsed.netloc or parsed.path
    return raw.split("/")[0]


def build_arg_parser():
    p = argparse.ArgumentParser(
        prog="sentrax",
        description="SentraX-CLI — Terminal Website Security Scanner",
        formatter_class=argparse.RawDescriptionHelpFormatter,
        epilog=__doc__,
    )
    p.add_argument("-d", "--domain", required=True, help="Target domain or URL, e.g. example.com")
    p.add_argument("-c", "--config", default=DEFAULT_CONFIG_PATH, help="Path to config.yaml (default: bundled config.yaml)")
    p.add_argument(
        "-m", "--modules",
        help="Comma-separated modules to run (overrides config.yaml toggles). "
             f"Available: {', '.join(MODULE_MAP.keys())}",
    )
    p.add_argument(
        "-f", "--format",
        help="Comma-separated output formats: terminal,json,html (overrides config.yaml)",
    )
    p.add_argument("-o", "--output", help="Output directory for reports (overrides config.yaml)")
    p.add_argument("--no-banner", action="store_true", help="Suppress the startup banner")
    p.add_argument("-v", "--verbose", action="store_true", help="Verbose output")
    return p


def main():
    colorama_init(autoreset=False)
    args = build_arg_parser().parse_args()
    cfg = load_config(args.config)

    if args.verbose:
        cfg["general"]["verbose"] = True

    domain = normalize_domain(args.domain)

    if not args.no_banner:
        banner.print_banner()

    # Determine which modules to run
    if args.modules:
        requested = [m.strip() for m in args.modules.split(",")]
        active_modules = [m for m in requested if m in MODULE_MAP]
        unknown = [m for m in requested if m not in MODULE_MAP]
        if unknown:
            print(f"[!] Ignoring unknown module(s): {', '.join(unknown)}")
    else:
        active_modules = [m for m, enabled in cfg.get("modules", {}).items() if enabled and m in MODULE_MAP]

    if not active_modules:
        print("[!] No modules selected to run. Exiting.")
        sys.exit(1)

    print(f"[*] Target: {domain}")
    print(f"[*] Modules: {', '.join(active_modules)}\n")

    results = {}
    for mod_name in active_modules:
        print(f"[>] Running {mod_name} ...", end=" ", flush=True)
        start = time.time()
        try:
            mod_result = MODULE_MAP[mod_name].run(domain, cfg)
        except Exception as e:
            mod_result = {"module": mod_name, "status": "error", "data": {}, "error": f"Unhandled exception: {e}"}
        elapsed = time.time() - start
        print(f"done ({elapsed:.1f}s)")
        results[mod_name] = mod_result

    # Determine output formats
    if args.format:
        formats = [f.strip().lower() for f in args.format.split(",")]
    else:
        formats = cfg.get("report", {}).get("formats", ["terminal"])

    output_dir = args.output or cfg.get("report", {}).get("output_dir", "reports")

    if "terminal" in formats:
        report_generator.print_terminal_report(domain, results)

    if "json" in formats:
        path = report_generator.save_json_report(domain, results, output_dir)
        print(f"[+] JSON report saved: {path}")

    if "html" in formats:
        path = report_generator.save_html_report(domain, results, output_dir)
        print(f"[+] HTML report saved: {path}")


if __name__ == "__main__":
    try:
        main()
    except KeyboardInterrupt:
        print("\n[!] Scan interrupted by user.")
        sys.exit(130)
