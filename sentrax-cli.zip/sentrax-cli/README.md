# SentraX-CLI

A terminal-based website security scanner. The command-line companion to [SentraX](https://sentrax.lovable.app) — same idea, but built for Linux terminals, scriptable, and fully open source.

```
   _____ ______ _   _ _______ _____            __   __
  / ____|  ____| \ | |__   __|  __ \    /\     \ \ / /
 | (___ | |__  |  \| |  | |  | |__) |  /  \     \ V /
  \___ \|  __| | . ` |  | |  |  _  /  / /\ \     > <
  ____) | |____| |\  |  | |  | | \ \ / ____ \   / . \
 |_____/|______|_| \_|  |_|  |_|  \_/_/    \_\ /_/ \_\
```

## What it checks

| Module | What it does |
|---|---|
| `whois` | Registrar, creation/expiry dates, name servers |
| `dns` | A, AAAA, MX, NS, TXT, CNAME, SOA records |
| `ssl` | Certificate expiry, issuer, TLS protocol version, weak cipher detection |
| `headers` | Missing/present HTTP security headers, information-disclosure headers |
| `subdomains` | Passive subdomain discovery via certificate transparency logs (crt.sh) — no active brute forcing |
| `ports` | Fast TCP-connect scan across a configurable list of common ports |
| `tech_detect` | Lightweight fingerprinting (CMS, frameworks, CDNs, analytics) |
| `robots_sitemap` | Fetches robots.txt / sitemap.xml, flags disallowed paths that look sensitive (admin, backup, .env, etc.) |

Every module is independent — drop in your own under `modules/` and register it in `sentrax.py`'s `MODULE_MAP` to extend the tool.

## Install

```bash
git clone https://github.com/yourusername/sentrax-cli.git
cd sentrax-cli
pip install -r requirements.txt
```

Requires Python 3.9+.

## Usage

```bash
# Full scan, all modules, terminal + JSON output
python3 sentrax.py -d example.com

# Only run specific modules
python3 sentrax.py -d example.com --modules ssl,headers,dns

# Export HTML + JSON report to a custom folder
python3 sentrax.py -d example.com --format json,html --output ./my_reports

# Use a custom config file
python3 sentrax.py -d example.com --config myconfig.yaml

# Verbose mode, no banner (good for scripting/CI)
python3 sentrax.py -d example.com --no-banner --verbose
```

### Flags

| Flag | Description |
|---|---|
| `-d, --domain` | Target domain or URL (required) |
| `-c, --config` | Path to a config.yaml (default: bundled `config.yaml`) |
| `-m, --modules` | Comma-separated modules to run, overrides config |
| `-f, --format` | Comma-separated output formats: `terminal`, `json`, `html` |
| `-o, --output` | Output directory for saved reports |
| `--no-banner` | Suppress the startup banner |
| `-v, --verbose` | Verbose output |

## Customization

Everything runs off `config.yaml`, so you don't need to touch code to change behavior:

```yaml
general:
  timeout: 6
  threads: 20
  user_agent: "SentraX-CLI/1.0"

modules:
  whois: true
  ports: false   # turn a module off entirely

ports:
  common_ports: [80, 443, 8080]   # scan only what you care about

report:
  formats: ["terminal", "html"]
  output_dir: "reports"
```

## Adding your own module

1. Create `modules/my_check.py` with a `run(domain, cfg) -> dict` function that returns:
   ```python
   {"module": "my_check", "status": "ok" | "warning" | "error", "data": {...}, "error": None}
   ```
2. Add `"my_check": my_check` to `MODULE_MAP` in `sentrax.py`.
3. Add `my_check: true` under `modules:` in `config.yaml`.

## Legal / Ethical Use

This tool is for scanning **domains you own or have explicit written authorization to test**. Port scanning, subdomain enumeration, and vulnerability probing against systems you don't have permission to test can violate laws like the Computer Fraud and Abuse Act (US), the Computer Misuse Act (UK), and equivalent laws in most other countries — including Tanzania's Cybercrimes Act. Always get permission first.

## License

MIT — see `LICENSE`.

---
Built by Arqam — [CoreSec Solutions](https://sentrax.lovable.app)
