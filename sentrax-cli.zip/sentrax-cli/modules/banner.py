"""
banner.py - SentraX-CLI startup banner
"""

from colorama import Fore, Style

VERSION = "1.0.0"

BANNER = r"""
   _____ ______ _   _ _______ _____            __   __
  / ____|  ____| \ | |__   __|  __ \    /\     \ \ / /
 | (___ | |__  |  \| |  | |  | |__) |  /  \     \ V /
  \___ \|  __| | . ` |  | |  |  _  /  / /\ \     > <
  ____) | |____| |\  |  | |  | | \ \ / ____ \   / . \
 |_____/|______|_| \_|  |_|  |_|  \_/_/    \_\ /_/ \_\
"""

def print_banner():
    print(Fore.GREEN + Style.BRIGHT + BANNER)
    print(Fore.CYAN + f"        SentraX-CLI v{VERSION}  |  Terminal Website Security Scanner")
    print(Fore.CYAN + "        by Arqam / CoreSec Solutions  —  github project")
    print(Fore.YELLOW + "        Use only against targets you own or are authorized to test.\n")
    print(Style.RESET_ALL, end="")
