"""
port_scan.py - Lightweight TCP-connect scan across a configurable common-port list.
Not a replacement for nmap; intended for a fast surface-level check.
"""

import socket
from concurrent.futures import ThreadPoolExecutor, as_completed

COMMON_SERVICE_NAMES = {
    21: "FTP", 22: "SSH", 25: "SMTP", 53: "DNS", 80: "HTTP",
    110: "POP3", 143: "IMAP", 443: "HTTPS", 465: "SMTPS",
    587: "SMTP-Submission", 993: "IMAPS", 995: "POP3S",
    3306: "MySQL", 3389: "RDP", 5432: "PostgreSQL",
    8080: "HTTP-Alt", 8443: "HTTPS-Alt",
}


def _check_port(host, port, timeout):
    try:
        with socket.create_connection((host, port), timeout=timeout):
            return port, True
    except Exception:
        return port, False


def run(domain, cfg):
    result = {"module": "ports", "status": "ok", "data": {}, "error": None}
    timeout = min(cfg["general"]["timeout"], 3)  # keep per-port timeout short
    threads = cfg["general"].get("threads", 20)
    ports = cfg.get("ports", {}).get("common_ports", list(COMMON_SERVICE_NAMES.keys()))

    try:
        ip = socket.gethostbyname(domain)
    except Exception as e:
        result["status"] = "error"
        result["error"] = f"Could not resolve host: {e}"
        return result

    open_ports = []
    try:
        with ThreadPoolExecutor(max_workers=threads) as executor:
            futures = [executor.submit(_check_port, ip, p, timeout) for p in ports]
            for future in as_completed(futures):
                port, is_open = future.result()
                if is_open:
                    open_ports.append(port)
    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)
        return result

    open_ports.sort()
    risky_open = [p for p in open_ports if p in (21, 23, 3306, 3389, 5432)]
    findings = []
    if risky_open:
        findings.append(
            "Potentially sensitive services exposed publicly: "
            + ", ".join(f"{p}/{COMMON_SERVICE_NAMES.get(p, 'unknown')}" for p in risky_open)
        )

    result["data"] = {
        "resolved_ip": ip,
        "open_ports": [{"port": p, "service": COMMON_SERVICE_NAMES.get(p, "unknown")} for p in open_ports],
        "scanned_count": len(ports),
        "findings": findings,
    }
    if findings:
        result["status"] = "warning"
    return result
