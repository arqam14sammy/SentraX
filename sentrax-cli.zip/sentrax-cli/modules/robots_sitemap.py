"""
robots_sitemap.py - Fetch robots.txt and sitemap.xml, flag interesting disallowed paths
"""

import requests

SENSITIVE_KEYWORDS = ["admin", "login", "config", "backup", "private", "internal", "staging", "wp-admin", ".env"]


def run(domain, cfg):
    result = {"module": "robots_sitemap", "status": "ok", "data": {}, "error": None}
    timeout = cfg["general"]["timeout"]
    ua = cfg["general"]["user_agent"]
    base = f"https://{domain}"

    data = {"robots_txt_found": False, "sitemap_found": False, "disallowed_paths": [], "interesting_paths": []}

    try:
        r = requests.get(f"{base}/robots.txt", timeout=timeout, headers={"User-Agent": ua})
        if r.status_code == 200 and r.text.strip():
            data["robots_txt_found"] = True
            disallowed = []
            for line in r.text.splitlines():
                line = line.strip()
                if line.lower().startswith("disallow:"):
                    path = line.split(":", 1)[1].strip()
                    if path:
                        disallowed.append(path)
            data["disallowed_paths"] = disallowed
            data["interesting_paths"] = [
                p for p in disallowed if any(k in p.lower() for k in SENSITIVE_KEYWORDS)
            ]
    except Exception as e:
        result["error"] = f"robots.txt fetch failed: {e}"

    try:
        r = requests.get(f"{base}/sitemap.xml", timeout=timeout, headers={"User-Agent": ua})
        if r.status_code == 200 and "<urlset" in r.text.lower() or "<sitemapindex" in r.text.lower():
            data["sitemap_found"] = True
    except Exception:
        pass

    result["data"] = data
    if data["interesting_paths"]:
        result["status"] = "warning"
    return result
