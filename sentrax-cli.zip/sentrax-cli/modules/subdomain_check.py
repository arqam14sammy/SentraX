"""
subdomain_check.py - Passive subdomain enumeration via crt.sh (certificate transparency)
No brute forcing / no active probing of third-party infra beyond a public API query.
"""

import requests


def run(domain, cfg):
    result = {"module": "subdomains", "status": "ok", "data": {}, "error": None}
    timeout = cfg["general"]["timeout"]
    max_results = cfg.get("subdomains", {}).get("max_results", 50)
    url = f"https://crt.sh/?q=%25.{domain}&output=json"

    try:
        resp = requests.get(url, timeout=timeout)
        if resp.status_code != 200:
            result["status"] = "warning"
            result["error"] = f"crt.sh returned status {resp.status_code}"
            result["data"] = {"subdomains": []}
            return result

        entries = resp.json()
        subs = set()
        for entry in entries:
            name_value = entry.get("name_value", "")
            for line in name_value.split("\n"):
                line = line.strip().lower()
                if line.endswith(domain) and "*" not in line:
                    subs.add(line)

        sorted_subs = sorted(subs)[:max_results]
        result["data"] = {
            "count_found": len(subs),
            "subdomains": sorted_subs,
        }
    except ValueError:
        result["status"] = "warning"
        result["error"] = "crt.sh returned non-JSON response (rate-limited or empty)"
        result["data"] = {"subdomains": []}
    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)
    return result
