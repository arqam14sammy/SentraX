"""
headers_check.py - HTTP response & security header analysis
"""

import requests

SECURITY_HEADERS = {
    "Strict-Transport-Security": "Enforces HTTPS connections (HSTS). Missing allows downgrade attacks.",
    "Content-Security-Policy": "Restricts sources of scripts/styles, mitigating XSS.",
    "X-Frame-Options": "Prevents clickjacking via iframe embedding.",
    "X-Content-Type-Options": "Prevents MIME-sniffing attacks (should be 'nosniff').",
    "Referrer-Policy": "Controls how much referrer info is leaked cross-origin.",
    "Permissions-Policy": "Restricts access to browser features (camera, mic, geolocation).",
    "Cross-Origin-Opener-Policy": "Isolates browsing context to prevent cross-window attacks.",
    "Cross-Origin-Resource-Policy": "Restricts which origins can load this resource.",
}

INFO_LEAK_HEADERS = ["Server", "X-Powered-By", "X-AspNet-Version", "X-AspNetMvc-Version"]


def run(domain, cfg):
    result = {"module": "headers", "status": "ok", "data": {}, "error": None}
    timeout = cfg["general"]["timeout"]
    ua = cfg["general"]["user_agent"]
    url = f"https://{domain}"

    try:
        resp = requests.get(url, timeout=timeout, headers={"User-Agent": ua}, allow_redirects=True, verify=True)
    except requests.exceptions.SSLError:
        try:
            resp = requests.get(f"http://{domain}", timeout=timeout, headers={"User-Agent": ua}, allow_redirects=True)
        except Exception as e:
            result["status"] = "error"
            result["error"] = f"Could not connect over HTTPS or HTTP: {e}"
            return result
    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)
        return result

    headers = resp.headers
    missing = [h for h in SECURITY_HEADERS if h not in headers]
    present = {h: headers[h] for h in SECURITY_HEADERS if h in headers}
    leaks = {h: headers[h] for h in INFO_LEAK_HEADERS if h in headers}

    findings = [f"Missing header: {h} — {SECURITY_HEADERS[h]}" for h in missing]
    if leaks:
        findings.append(f"Information disclosure via headers: {', '.join(f'{k}={v}' for k, v in leaks.items())}")

    result["data"] = {
        "final_url": resp.url,
        "status_code": resp.status_code,
        "present_security_headers": present,
        "missing_security_headers": missing,
        "info_leak_headers": leaks,
        "findings": findings,
    }
    if findings:
        result["status"] = "warning"
    return result
