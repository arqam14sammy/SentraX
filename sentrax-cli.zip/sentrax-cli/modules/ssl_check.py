"""
ssl_check.py - TLS certificate and protocol inspection
"""

import ssl
import socket
import datetime


def run(domain, cfg):
    result = {"module": "ssl", "status": "ok", "data": {}, "error": None}
    timeout = cfg["general"]["timeout"]
    port = 443

    try:
        ctx = ssl.create_default_context()
        with socket.create_connection((domain, port), timeout=timeout) as sock:
            with ctx.wrap_socket(sock, server_hostname=domain) as ssock:
                cert = ssock.getpeercert()
                cipher = ssock.cipher()
                protocol = ssock.version()

        not_after = cert.get("notAfter")
        not_before = cert.get("notBefore")
        expires_dt = None
        days_left = None
        if not_after:
            expires_dt = datetime.datetime.strptime(not_after, "%b %d %H:%M:%S %Y %Z")
            days_left = (expires_dt - datetime.datetime.utcnow()).days

        issuer = dict(x[0] for x in cert.get("issuer", []))
        subject = dict(x[0] for x in cert.get("subject", []))
        san = [entry[1] for entry in cert.get("subjectAltName", [])]

        findings = []
        if days_left is not None and days_left < 15:
            findings.append(f"Certificate expires soon ({days_left} days left)")
        if protocol in ("TLSv1", "TLSv1.1", "SSLv3", "SSLv2"):
            findings.append(f"Outdated/insecure protocol negotiated: {protocol}")
        weak_ciphers = ["RC4", "DES", "3DES", "MD5", "NULL", "EXPORT"]
        if cipher and any(w in cipher[0] for w in weak_ciphers):
            findings.append(f"Weak cipher suite negotiated: {cipher[0]}")

        result["data"] = {
            "issuer": issuer,
            "subject": subject,
            "valid_from": not_before,
            "valid_until": not_after,
            "days_until_expiry": days_left,
            "protocol": protocol,
            "cipher_suite": cipher[0] if cipher else None,
            "subject_alt_names": san,
            "findings": findings,
        }
        if findings:
            result["status"] = "warning"

    except ssl.SSLCertVerificationError as e:
        result["status"] = "warning"
        result["data"] = {"findings": ["Certificate verification failed: possible self-signed or expired cert"]}
        result["error"] = str(e)
    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)
    return result
