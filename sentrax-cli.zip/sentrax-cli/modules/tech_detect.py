"""
tech_detect.py - Lightweight technology fingerprinting from headers + HTML markers
"""

import re
import requests

SIGNATURES = {
    "WordPress": [r"wp-content", r"wp-includes"],
    "Shopify": [r"cdn\.shopify\.com", r"Shopify\.theme"],
    "React": [r"__NEXT_DATA__|react\.production|data-reactroot"],
    "Next.js": [r"__NEXT_DATA__", r"/_next/static"],
    "Vue.js": [r"__vue__|/js/vue\."],
    "Laravel": [r"laravel_session"],
    "Django": [r"csrftoken"],
    "Cloudflare": [r"cloudflare"],
    "Nginx": [r"nginx"],
    "Apache": [r"apache"],
    "jQuery": [r"jquery(\.min)?\.js"],
    "Bootstrap": [r"bootstrap(\.min)?\.css"],
    "Google Analytics": [r"google-analytics\.com|gtag\("],
    "Supabase": [r"supabase\.co"],
    "Lovable": [r"lovable\.app|lovable\.dev"],
}


def run(domain, cfg):
    result = {"module": "tech_detect", "status": "ok", "data": {}, "error": None}
    timeout = cfg["general"]["timeout"]
    ua = cfg["general"]["user_agent"]

    try:
        resp = requests.get(f"https://{domain}", timeout=timeout, headers={"User-Agent": ua})
    except Exception:
        try:
            resp = requests.get(f"http://{domain}", timeout=timeout, headers={"User-Agent": ua})
        except Exception as e:
            result["status"] = "error"
            result["error"] = str(e)
            return result

    body = resp.text
    header_blob = " ".join(f"{k}:{v}" for k, v in resp.headers.items())
    haystack = body + " " + header_blob

    detected = []
    for tech, patterns in SIGNATURES.items():
        for pat in patterns:
            if re.search(pat, haystack, re.IGNORECASE):
                detected.append(tech)
                break

    result["data"] = {
        "detected_technologies": sorted(set(detected)),
        "server_header": resp.headers.get("Server"),
        "powered_by_header": resp.headers.get("X-Powered-By"),
    }
    return result
