"""
whois_check.py - Domain registration / ownership lookup
"""

def run(domain, cfg):
    result = {"module": "whois", "status": "ok", "data": {}, "error": None}
    try:
        import whois
        import socket
        socket.setdefaulttimeout(cfg["general"]["timeout"])
        w = whois.whois(domain)

        def clean(val):
            if isinstance(val, list):
                return [str(v) for v in val]
            if val is None:
                return None
            return str(val)

        result["data"] = {
            "registrar": clean(w.registrar),
            "creation_date": clean(w.creation_date),
            "expiration_date": clean(w.expiration_date),
            "updated_date": clean(w.updated_date),
            "name_servers": clean(w.name_servers),
            "org": clean(getattr(w, "org", None)),
            "country": clean(getattr(w, "country", None)),
            "emails": clean(getattr(w, "emails", None)),
            "status": clean(w.status),
        }
    except Exception as e:
        result["status"] = "error"
        result["error"] = str(e)
    return result
