"""
dns_check.py - DNS record enumeration (A, AAAA, MX, NS, TXT, CNAME, SOA)
"""

import dns.resolver

RECORD_TYPES = ["A", "AAAA", "MX", "NS", "TXT", "CNAME", "SOA"]


def run(domain, cfg):
    result = {"module": "dns", "status": "ok", "data": {}, "error": None}
    resolver = dns.resolver.Resolver()
    resolver.timeout = cfg["general"]["timeout"]
    resolver.lifetime = cfg["general"]["timeout"]

    records = {}
    any_success = False
    for rtype in RECORD_TYPES:
        try:
            answers = resolver.resolve(domain, rtype)
            records[rtype] = sorted([a.to_text() for a in answers])
            any_success = True
        except dns.resolver.NoAnswer:
            records[rtype] = []
        except dns.resolver.NXDOMAIN:
            result["status"] = "error"
            result["error"] = "Domain does not exist (NXDOMAIN)"
            return result
        except Exception as e:
            records[rtype] = []

    result["data"] = records
    if not any_success:
        result["status"] = "warning"
        result["error"] = "No DNS records resolved for any queried type"
    return result
